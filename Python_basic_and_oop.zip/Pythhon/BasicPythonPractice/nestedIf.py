

a=int(input("enter a number : "))
b=4

if (a>11):
    if(a<14):
        print("perfect")
    else:
        print("wrong")
else:
    print("incorrect")


















"""a=10
b=23

if (a>12 and b<24):
    print("this is right")

if (a>11 or b<24):
    print("ok")

c=12
print(not(b>c))"""