
count=10
x=int(input("enter number :"))
while(count<x):
    if (count%2!=0):
        print(count)
    count=count+1