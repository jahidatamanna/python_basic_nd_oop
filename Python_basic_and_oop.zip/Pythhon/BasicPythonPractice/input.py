
"""x=input("enter your name: ")
print(x)"""

x=int(input("enter your age : "))
y=int(10)
z=x+y
print(z)