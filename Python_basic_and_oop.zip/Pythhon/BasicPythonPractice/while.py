
count=0
while count<5:
    count+=1
    if count==4:
        continue
    print(count)
    
    