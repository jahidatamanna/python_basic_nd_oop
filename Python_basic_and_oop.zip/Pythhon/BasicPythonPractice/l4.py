
print("bangladesh is",end=" ")
#print("is",sep=" ")
print("my",end=" ")
print("country")
print("hlw","world",sep=" ")