

"""for x in range(1,11,2):
    print(x)"""


x=['p','r','u']
y=[10,22,1]
for m in x:
   print(x)
   """ for n in y:
        print(m,n)"""





"""a=[12,43,23,56,77,8,90]
largest=10
for i in a:
    if largest<i:
        largest=i
print(largest)"""