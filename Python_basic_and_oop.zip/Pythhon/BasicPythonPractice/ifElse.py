
a=int(input("enter a number : "))
b=5
c=["p","ad"]
d="p"


if a>10:
    print("right answer")
if b<a:
    print(" a is bigger than b")

if d in c:
    print("yes")

if a%2:
    print("odd number")

else :
    print("nothing")