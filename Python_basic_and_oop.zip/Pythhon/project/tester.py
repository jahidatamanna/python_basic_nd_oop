

from project_2 import book

b1 = book.Book("Shankhachur", "Shadat Hosain")
b1.view() 