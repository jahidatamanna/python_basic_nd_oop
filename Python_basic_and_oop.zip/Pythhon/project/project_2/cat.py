
class cat:
    def __init__(self,color,action):
        self.color=color
        self.action=action


    def view(self):
        print(self.color,"is",self.action)


    def compare(self,ct):
        if self.action==ct.action:
            print("both cat are",ct.action)

        else:
            print("they are different")


c1=cat("white","jumping")
c2=cat("brown","sitting")
c1.view()
c2.view()
c1.compare(c2)
