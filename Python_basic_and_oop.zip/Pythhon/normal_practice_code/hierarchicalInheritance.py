
class student:
    def __init__(self,name,id):
        self.name=name
        self.id=id
    def details(self):
        print("name : ",self.name," id :",self.id)

class cse(student):
    def __init__(self, name, id,labs):
        super().__init__(name,id)
        self.lab=labs
    def cry(self):
        print("cse student are always crying because of there ",self.lab," labs")
        
class bba(student):
    def party(self):
        print("all day party")

c1=cse("tamu",12,4)
b1=bba("tanjila",13)

c1.details()
c1.cry()

b1.details()
b1.party()

print(help(c1))