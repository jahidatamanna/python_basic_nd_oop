
class student:
    def __init__(self,name,id):
        self.name=name
        self.id=id
        print(self)

    def __str__(self):
        return "this is "+self.name 
    
obj=student("tamu",12)
print(obj)
print(obj.__str__())