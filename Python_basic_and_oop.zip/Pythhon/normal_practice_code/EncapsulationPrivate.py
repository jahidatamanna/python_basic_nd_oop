
class student:
    def __init__(self,name,id):
        self.name=name # instance variable
        self.id=id # private variable

    def details(self):
       print("name : ",self.name,"id : ",self.id)
       self.__method()
       

    def __method(self): # private method(__)double under score
       print("private method")

s1=student("p",1)
s2=student("q",2)


s1.details()
s2.details()
       

