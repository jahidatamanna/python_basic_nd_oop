
class Animal:
    def __init__(self,name):
        self.name=name
    def eat(self):
        print(self.name," is eating")
class dog(Animal):
    def bark(self):
        print(self.name," is barking")

a1=Animal("C")
d1=dog("D")
a1.eat()
d1.bark()
d1.eat()

#isinstance check (isinstance(obj,className))
print(isinstance(a1,Animal)) # true
print(isinstance(a1,dog)) #false
print(isinstance(d1,dog)) # true
print(isinstance(d1,Animal)) # true

# issubclass check (issubclass(class,className))
print(issubclass(Animal,dog)) # false
print(issubclass(dog,Animal)) # true



        