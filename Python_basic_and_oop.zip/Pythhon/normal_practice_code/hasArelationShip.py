
class Engine:
    def __init__(self,cc):
        self.capacity=cc
    def start(self):
        print("engine is starting")

    def stop(self):
        print("engine is stoped")
class car:
    def __init__(self,name,cc):
        self.name=name
        self.engine=Engine(cc) # object create

    def run(self):
        self.engine.start()
        print("car is running")

c1=car("BMW",2000)
c1.run()


                