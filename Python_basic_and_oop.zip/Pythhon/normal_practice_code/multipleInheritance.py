
class a:
    def __init__(self):
        print("init method of class a")
    def method1(self):
        print("method1 of class a")

class b:
    def __init__(self):
        print("init method of class b")
    def method1(self):
        print("method1 of class b")

class c(a,b):
    def __init__(self):
        #super().__init__() # lrft to right execute
        #b.__init__(self) # specific class value execute such as here class b will execute
        print("init method of class c")

    def method2(self):
        print("method1 of class c")

obj=c()
obj.method1()
b.method1(obj) # specific method of specific class, value execute such as here class b  will execute 