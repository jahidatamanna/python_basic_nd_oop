
class A:
    def __init__(self):
        print("hlw")

    def method1(self): # method overriding
        print("method one from class A")

    def method2(self):
        print("method2 from class A")

class B(A):
    def __init__(self):
        pass
    def method1(self):  # method overriding
        
        print("method1 from class B")
        super().method1()
        

obj=B()
obj.method1()
obj.method2()