# variable overriding
class Animal:
    def __init__(self,name):
        self.name=name
        self.color="white"
    def details(self):
        print(self.color,self.name,"is eating")

class Dog(Animal):
    def __init__(self, name,color):
        super().__init__(name)
        self.color=color # variable overriding
    def bark(self):
        print(self.color," is is barking ")
d1=Dog("A","black")
d1.details()
d1.bark()
