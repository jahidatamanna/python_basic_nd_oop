
class student:
    def __init__(self,name,id):
        self.name=name # instance variable
        self.__id=id # private variable (its work only inside of the class)

    def view(self):
        print("name : ",self.name," id :" ,self.__id)

    def set_id(self,id):
        if (id>0):
            self.__id=id
        else:
            print("this id is invalid")
    def get_id(self):
        return self.__id
    
    def set_name(self,name):
        self.name=name

    def get_name(self):
        return self.name


s1=student("x",10)
s2=student("y",11)

s1.name="p" #otput ame=p bcz name is not private variable

s1.set_id(15)
s1.get_id()

s2.set_name("Z")
s2.get_name()



s1.view()
s2.view()