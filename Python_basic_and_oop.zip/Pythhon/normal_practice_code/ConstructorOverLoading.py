class student:

    """def __init__(self,*info):
        if len(info)==3:
            self.name=info[0]
            self.id=info[1]
            self.cgpa=info[2]

        elif len(info)==2:
            self.name=info[0]
            self.id=info[1]

        elif len(info)==1:
            self.name=info[0]

        print("hlw")"""

    def __init__(self,**info): # if we use (**info) there will be no effect on order
        if len(info)==3:
            self.name=info['name']
            self.id=info['id']
            self.cgpa=info['cgpa'] 

        elif len(info)==2:
            self.name=info['name']
            self.id=info['id']

        elif len(info)==1:
            self.name=info['name']

        print("hlw")
    
        
# same name constructor
    """def __init__(self,name,id):
        self.name=name
        self.id=id
    def __init__(self,name,id,cgpa):
        self.name=name
        self.id=id
        self.cgpa=cgpa"""
 # for  *info   
"""stu1=student("tamu",12)
stu1=student("tamu",12)
stu1=student("tamu",12,3)"""

# for  **info
stu1=student(name="tamu")
stu1=student(name="tamu",id=12)
stu1=student(name="tamu",id=12,cgpa=3)
     