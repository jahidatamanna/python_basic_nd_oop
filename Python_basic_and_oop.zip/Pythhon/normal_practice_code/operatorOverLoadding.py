
''' class data:
    def __init__(self,x):
        self.x=x

    def __add__(self,other):
        return self.x+other.x
    
num1=data(5)
num2=data(10)
print(num1+num2) '''


class Library:
    def __init__(self,book,pen):
        self.book=book
        self.pen=pen

    def view(self):
        print("the person has",self.book,"book and ",self.pen," pen")

    def __add__(self,also):
        updateBook=self.book+also.book
        updatePen=self.pen+also.pen
        obj=Library(updateBook,updatePen)
        return obj
        #return "total book "+str(updateBook)+" total pen "+str(updatePen) # marge updateBook  updatePen
    
#==============================================================================================

p1=Library(2,3)
p2=Library(3,4)
p1.view()
p2.view()
# add method 
p3=p1+p2
p3.view()

#print(p1+p2)















