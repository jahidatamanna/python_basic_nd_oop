
class student: # class
    uni_name="aiub" # class variable
    def __init__(self,name,id): # constructor
        self.name=name  #i nstance variable
        self.__id=id  # private variable

    def details(self): # instance method
        print("name:",self.name," id:",self.__id," uniName:",student.uni_name)

    @classmethod # class method
    def up_uni_name(cls,up_uni):
        cls.uni_name=up_uni

    @classmethod # class method
    def from_string(cls,info):
        name,id=info.split('-')
        obj=cls(name,id)
        return obj
    
#=============================================================================

s1=student("tamanna",11)
s2=student.from_string("jaheda-22")
s1.details()
s2.details()
student.up_uni_name("AIUB")
s1.details()
s2.details()
    
         
    