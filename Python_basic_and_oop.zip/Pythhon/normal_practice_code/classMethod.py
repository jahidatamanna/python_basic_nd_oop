
class student:
    uni_name="aiub"
    def __init__(self,name,id):
        self.name=name
        self.id=id
    def details(self):
        print("name:",self.name," id:",self.id," uniName : ",student.uni_name)
    @classmethod
    def update_uniName(cls,u_name):
        student.uni_name=u_name


s1=student("tamanna",11)
s2=student("jahida",22)
s1.details()
s2.details()
print("After updated uni_name")
student.update_uniName("AIUB")
s1.details()
s2.details()
