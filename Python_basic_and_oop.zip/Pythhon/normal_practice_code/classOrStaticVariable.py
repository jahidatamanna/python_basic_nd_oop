class Player:
    total_run=0 # class or static variable :it will be execute without object 
    def __init__(self,run):
        self.run=run # instance variable:it will not be execute without object 
        

    def hit_six(self):
        self.run+=6
        Player.total_run+=6

    def hit_four(self):
        self.run+=4
        Player.total_run+=4

#==========================================================================================================================================

print(Player.total_run) # before create a object the static or class variable can be executed

sakib=Player(0)
tamim=Player(0)

sakib.hit_four()
sakib.hit_four()
sakib.hit_six()

tamim.hit_six()
tamim.hit_four()


print("sakib : ",sakib.run)
print("total : ",sakib.total_run)
print("tamim : ",tamim.run)
print("Total run : ",Player.total_run)

