
class student:
    count=0
    def __init__(self,name,id):
        self.name=name
        self.id=id
        student.count+=1

    def details(self):
        print("name : ",self.name,"id : ",self.id)

print("student count : ", student.count)

s1=student("tamu ",11)
s2=student("jaheda ",22)

s1.details()
s2.details()

print("student count : ", student.count)
