
class student:  # Grand parent class
    def __init__(self,name,id):
        self.name=name
        self.id=id

    def details(self):
        print("name :",self.name," id :",self.id)

class cse(student):  # parent class
    def __init__(self, name, id,labs):
        super().__init__(name, id)
        self.labs=labs
    def cry(self):
        print(self.name,"is cring because they have ",self.labs," class")

class cseFreshers(cse): # child class
    def course(self):
        print(self.name," have 4 courses in his first semester ")

c1=cse("p",12,3)
cf1=cseFreshers("q",21,2)

c1.details()
c1.cry()
cf1.details()
cf1.course()
        