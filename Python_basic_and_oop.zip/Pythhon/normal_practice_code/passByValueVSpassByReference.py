
class cat:
    def __init__(self,color,action):
        self.color=color
        self.action=action
  
    def view(self,num,clr):
        num=num+5 # pass by value
        print("Method inside: ",num,"color :",self.color,"action:",self.action)# pass by value
        #clrs=clr # we can take any variable
        clr[0]="Green"
        print("Method inside: ",clr,"color :",self.color,"action:",self.action) # pass by reference

c1=cat("white","jumping")
colors=["Black","Blue","Red"] # pass by reference
x=55 # pass by value
c1.view(x,colors) # pass by value nd reference
print("method out side",x) # pass by value
print("method out side",colors) # pass by reference




