

class student: # class
    uni_name="aiub" # class variable
    def __init__(self,name,id): # constructor
        self.name=name  # instance variable
        self.__id=id  # private variable

    def details(self): # instance method
        print("name:",self.name," id:",self.__id," uniName:",student.uni_name)

    @classmethod # class method
    def up_uni_name(cls,up_uni):
        cls.uni_name=up_uni
    @staticmethod
    def chk_department(Id):
        if   Id[3:5]=="11": print("cse")
        elif Id[3:5]=="22": print("eee")
   
    
#=============================================================================
student.chk_department("1231197")
student.chk_department("1232297")
s1=student("tamanna",11)
s2=student("jaheda ",22)
s1.details()
s2.details()
student.up_uni_name("AIUB")
s1.details()
s2.details()
    
         
    